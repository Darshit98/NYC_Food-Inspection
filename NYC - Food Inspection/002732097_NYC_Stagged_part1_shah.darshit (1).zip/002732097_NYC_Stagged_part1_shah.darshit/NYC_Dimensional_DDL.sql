/*
 * ER/Studio Data Architect SQL Code Generation
 * Project :      NYCDimensionalModel.DM1
 *
 * Date Created : Sunday, June 18, 2023 23:10:14
 * Target DBMS : Microsoft SQL Server 2019
 */

USE Dim_Stage_NYC
go
/* 
 * TABLE: DimAction 
 */

CREATE TABLE DimAction(
    ActionSK    int         IDENTITY(1,1),
    Action      char(10)    NOT NULL,
    CONSTRAINT PK13 PRIMARY KEY NONCLUSTERED (ActionSK)
)

go


IF OBJECT_ID('DimAction') IS NOT NULL
    PRINT '<<< CREATED TABLE DimAction >>>'
ELSE
    PRINT '<<< FAILED CREATING TABLE DimAction >>>'
go

/* 
 * TABLE: DimAddress 
 */

CREATE TABLE DimAddress(
    AddressSK          int               IDENTITY(1,1),
    Building           char(10)          NOT NULL,
    Street             char(10)          NOT NULL,
    ZipCode            int               NOT NULL,
    CouncilDistrict    char(10)          NOT NULL,
    Latitude           decimal(10, 0)    NOT NULL,
    Longitude          decimal(10, 0)    NOT NULL,
    LocationPoint      char(10)          NOT NULL,
    CONSTRAINT PK8 PRIMARY KEY NONCLUSTERED (AddressSK)
)

go


IF OBJECT_ID('DimAddress') IS NOT NULL
    PRINT '<<< CREATED TABLE DimAddress >>>'
ELSE
    PRINT '<<< FAILED CREATING TABLE DimAddress >>>'
go

/* 
 * TABLE: DimBoard 
 */

CREATE TABLE DimBoard(
    BoardSK           int         IDENTITY(1,1),
    CommunityBoard    char(10)    NOT NULL,
    CensusTrack       char(10)    NOT NULL,
    BIN               int         NOT NULL,
    BBL               char(10)    NOT NULL,
    NTA               char(10)    NOT NULL,
    CONSTRAINT PK11 PRIMARY KEY NONCLUSTERED (BoardSK)
)

go


IF OBJECT_ID('DimBoard') IS NOT NULL
    PRINT '<<< CREATED TABLE DimBoard >>>'
ELSE
    PRINT '<<< FAILED CREATING TABLE DimBoard >>>'
go

/* 
 * TABLE: DimCuisine 
 */

CREATE TABLE DimCuisine(
    CuisineSK             int         IDENTITY(1,1),
    CuisineDescription    char(10)    NOT NULL,
    CONSTRAINT PK9 PRIMARY KEY NONCLUSTERED (CuisineSK)
)

go


IF OBJECT_ID('DimCuisine') IS NOT NULL
    PRINT '<<< CREATED TABLE DimCuisine >>>'
ELSE
    PRINT '<<< FAILED CREATING TABLE DimCuisine >>>'
go

/* 
 * TABLE: DimDate 
 */

CREATE TABLE DimDate(
    FullDateAK          int         IDENTITY(1,1),
    DayNameOfWeek       char(10)    NOT NULL,
    DateSK              int         NOT NULL,
    DayNumberOfMonth    int         NOT NULL,
    DayNumberOfWeek     int         NOT NULL,
    WeekNumberOfYear    int         NOT NULL,
    MonthName           char(10)    NOT NULL,
    CalendarQuarter     int         NOT NULL,
    CalendarYear        int         NOT NULL,
    CONSTRAINT PK2 PRIMARY KEY NONCLUSTERED (FullDateAK)
)

go


IF OBJECT_ID('DimDate') IS NOT NULL
    PRINT '<<< CREATED TABLE DimDate >>>'
ELSE
    PRINT '<<< FAILED CREATING TABLE DimDate >>>'
go

/* 
 * TABLE: DimInspectionType 
 */

CREATE TABLE DimInspectionType(
    InspectionTypeSK    int         IDENTITY(1,1),
    InspectionType      char(10)    NOT NULL,
    CONSTRAINT PK12 PRIMARY KEY NONCLUSTERED (InspectionTypeSK)
)

go


IF OBJECT_ID('DimInspectionType') IS NOT NULL
    PRINT '<<< CREATED TABLE DimInspectionType >>>'
ELSE
    PRINT '<<< FAILED CREATING TABLE DimInspectionType >>>'
go

/* 
 * TABLE: DimRestaurant 
 */

CREATE TABLE DimRestaurant(
    RestaurantSK    int         IDENTITY(1,1),
    CAMIS           int         NOT NULL,
    DBA             char(10)    NOT NULL,
    Phone           int         NOT NULL,
    CuisineSK       int         NOT NULL,
    AddressSK       int         NOT NULL,
    BoardSK         int         NOT NULL,
    CONSTRAINT PK7 PRIMARY KEY NONCLUSTERED (RestaurantSK)
)

go


IF OBJECT_ID('DimRestaurant') IS NOT NULL
    PRINT '<<< CREATED TABLE DimRestaurant >>>'
ELSE
    PRINT '<<< FAILED CREATING TABLE DimRestaurant >>>'
go

/* 
 * TABLE: DimViolation 
 */

CREATE TABLE DimViolation(
    ViolationSK             int         IDENTITY(1,1),
    CriticalFlag            char(10)    NOT NULL,
    ViolationCode           int         NOT NULL,
    ViolationDescription    char(10)    NOT NULL,
    CONSTRAINT PK14 PRIMARY KEY NONCLUSTERED (ViolationSK)
)

go


IF OBJECT_ID('DimViolation') IS NOT NULL
    PRINT '<<< CREATED TABLE DimViolation >>>'
ELSE
    PRINT '<<< FAILED CREATING TABLE DimViolation >>>'
go

/* 
 * TABLE: Fact 
 */

CREATE TABLE Fact(
    Inspection_SK       int        IDENTITY(1,1),
    GradeDate           date       NOT NULL,
    RecordDate          date       NOT NULL,
    InspectionDate      date       NOT NULL,
    Grade               char(1)    NOT NULL,
    Score               int        NOT NULL,
    FullDateAK          int        NOT NULL,
    RestaurantSK        int        NOT NULL,
    InspectionTypeSK    int        NOT NULL,
    ActionSK            int        NOT NULL,
    ViolationSK         int        NOT NULL,
    CONSTRAINT PK10 PRIMARY KEY NONCLUSTERED (Inspection_SK)
)

go


IF OBJECT_ID('Fact') IS NOT NULL
    PRINT '<<< CREATED TABLE Fact >>>'
ELSE
    PRINT '<<< FAILED CREATING TABLE Fact >>>'
go

/* 
 * TABLE: DimRestaurant 
 */

ALTER TABLE DimRestaurant ADD CONSTRAINT RefDimCuisine7 
    FOREIGN KEY (CuisineSK)
    REFERENCES DimCuisine(CuisineSK)
go

ALTER TABLE DimRestaurant ADD CONSTRAINT RefDimAddress8 
    FOREIGN KEY (AddressSK)
    REFERENCES DimAddress(AddressSK)
go

ALTER TABLE DimRestaurant ADD CONSTRAINT RefDimBoard9 
    FOREIGN KEY (BoardSK)
    REFERENCES DimBoard(BoardSK)
go


/* 
 * TABLE: Fact 
 */

ALTER TABLE Fact ADD CONSTRAINT RefDimDate5 
    FOREIGN KEY (FullDateAK)
    REFERENCES DimDate(FullDateAK)
go

ALTER TABLE Fact ADD CONSTRAINT RefDimRestaurant6 
    FOREIGN KEY (RestaurantSK)
    REFERENCES DimRestaurant(RestaurantSK)
go

ALTER TABLE Fact ADD CONSTRAINT RefDimInspectionType10 
    FOREIGN KEY (InspectionTypeSK)
    REFERENCES DimInspectionType(InspectionTypeSK)
go

ALTER TABLE Fact ADD CONSTRAINT RefDimAction11 
    FOREIGN KEY (ActionSK)
    REFERENCES DimAction(ActionSK)
go

ALTER TABLE Fact ADD CONSTRAINT RefDimViolation12 
    FOREIGN KEY (ViolationSK)
    REFERENCES DimViolation(ViolationSK)
go


